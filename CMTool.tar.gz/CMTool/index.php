<?php
header("Content-Type: text/plain");
echo "Hello, world!\n";?>
